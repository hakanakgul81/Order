<?php 

class Detay extends CI_Controller {
	
	public function index(){
		echo "Detay Controllerinin index metodu";
	}

	public function urun(){
	echo "Detay controllerinin urun metodu";
	}

}